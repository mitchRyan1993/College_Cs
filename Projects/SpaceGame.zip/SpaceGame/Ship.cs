﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpaceGame
{
    public class Ship
    {
        public int Durability{ get; set; }

        public bool planet1Result { get; set; }

        public bool planet2Result { get; set; }

        public bool planet3Result { get; set; }
        
        public bool planet4Result { get; set; }
        
        public bool planet5Result { get; set; }

        public int Money { get; set; }
    }
}
