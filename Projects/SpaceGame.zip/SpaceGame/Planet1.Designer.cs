﻿
namespace SpaceGame
{
    partial class Planet1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox00 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox30 = new System.Windows.Forms.PictureBox();
            this.pictureBox31 = new System.Windows.Forms.PictureBox();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox01 = new System.Windows.Forms.PictureBox();
            this.pictureBox33 = new System.Windows.Forms.PictureBox();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.pictureBox03 = new System.Windows.Forms.PictureBox();
            this.pictureBox32 = new System.Windows.Forms.PictureBox();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox02 = new System.Windows.Forms.PictureBox();
            this.Randomize = new System.Windows.Forms.Button();
            this.pictureBoxEhh = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.playerGoldOutput = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox00)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox01)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox03)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox02)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEhh)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox00
            // 
            this.pictureBox00.Location = new System.Drawing.Point(207, 44);
            this.pictureBox00.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox00.Name = "pictureBox00";
            this.pictureBox00.Size = new System.Drawing.Size(100, 100);
            this.pictureBox00.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox00.TabIndex = 0;
            this.pictureBox00.TabStop = false;
            this.pictureBox00.Click += new System.EventHandler(this.pictureBox00_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Location = new System.Drawing.Point(304, 43);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(100, 100);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10.TabIndex = 1;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox20
            // 
            this.pictureBox20.Location = new System.Drawing.Point(401, 43);
            this.pictureBox20.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(100, 100);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox20.TabIndex = 2;
            this.pictureBox20.TabStop = false;
            this.pictureBox20.Click += new System.EventHandler(this.pictureBox20_Click);
            // 
            // pictureBox30
            // 
            this.pictureBox30.Location = new System.Drawing.Point(499, 43);
            this.pictureBox30.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox30.Name = "pictureBox30";
            this.pictureBox30.Size = new System.Drawing.Size(100, 100);
            this.pictureBox30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox30.TabIndex = 3;
            this.pictureBox30.TabStop = false;
            this.pictureBox30.Click += new System.EventHandler(this.pictureBox30_Click);
            // 
            // pictureBox31
            // 
            this.pictureBox31.Location = new System.Drawing.Point(499, 140);
            this.pictureBox31.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox31.Name = "pictureBox31";
            this.pictureBox31.Size = new System.Drawing.Size(100, 100);
            this.pictureBox31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox31.TabIndex = 7;
            this.pictureBox31.TabStop = false;
            this.pictureBox31.Click += new System.EventHandler(this.pictureBox31_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Location = new System.Drawing.Point(401, 140);
            this.pictureBox21.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(100, 100);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox21.TabIndex = 6;
            this.pictureBox21.TabStop = false;
            this.pictureBox21.Click += new System.EventHandler(this.pictureBox21_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Location = new System.Drawing.Point(304, 140);
            this.pictureBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(100, 100);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11.TabIndex = 5;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox01
            // 
            this.pictureBox01.Location = new System.Drawing.Point(207, 140);
            this.pictureBox01.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox01.Name = "pictureBox01";
            this.pictureBox01.Size = new System.Drawing.Size(100, 100);
            this.pictureBox01.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox01.TabIndex = 4;
            this.pictureBox01.TabStop = false;
            this.pictureBox01.Click += new System.EventHandler(this.pictureBox01_Click);
            // 
            // pictureBox33
            // 
            this.pictureBox33.Location = new System.Drawing.Point(499, 337);
            this.pictureBox33.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox33.Name = "pictureBox33";
            this.pictureBox33.Size = new System.Drawing.Size(100, 100);
            this.pictureBox33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox33.TabIndex = 15;
            this.pictureBox33.TabStop = false;
            this.pictureBox33.Click += new System.EventHandler(this.pictureBox33_Click);
            // 
            // pictureBox23
            // 
            this.pictureBox23.Location = new System.Drawing.Point(401, 337);
            this.pictureBox23.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(100, 100);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox23.TabIndex = 14;
            this.pictureBox23.TabStop = false;
            this.pictureBox23.Click += new System.EventHandler(this.pictureBox23_Click);
            // 
            // pictureBox13
            // 
            this.pictureBox13.Location = new System.Drawing.Point(304, 337);
            this.pictureBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(100, 100);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox13.TabIndex = 13;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Click += new System.EventHandler(this.pictureBox13_Click);
            // 
            // pictureBox03
            // 
            this.pictureBox03.Location = new System.Drawing.Point(207, 337);
            this.pictureBox03.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox03.Name = "pictureBox03";
            this.pictureBox03.Size = new System.Drawing.Size(100, 100);
            this.pictureBox03.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox03.TabIndex = 12;
            this.pictureBox03.TabStop = false;
            this.pictureBox03.Click += new System.EventHandler(this.pictureBox03_Click);
            // 
            // pictureBox32
            // 
            this.pictureBox32.Location = new System.Drawing.Point(499, 240);
            this.pictureBox32.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox32.Name = "pictureBox32";
            this.pictureBox32.Size = new System.Drawing.Size(100, 100);
            this.pictureBox32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox32.TabIndex = 11;
            this.pictureBox32.TabStop = false;
            this.pictureBox32.Click += new System.EventHandler(this.pictureBox32_Click);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Location = new System.Drawing.Point(401, 240);
            this.pictureBox22.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(100, 100);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox22.TabIndex = 10;
            this.pictureBox22.TabStop = false;
            this.pictureBox22.Click += new System.EventHandler(this.pictureBox22_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Location = new System.Drawing.Point(304, 240);
            this.pictureBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(100, 100);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12.TabIndex = 9;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // pictureBox02
            // 
            this.pictureBox02.Location = new System.Drawing.Point(207, 240);
            this.pictureBox02.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBox02.Name = "pictureBox02";
            this.pictureBox02.Size = new System.Drawing.Size(100, 100);
            this.pictureBox02.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox02.TabIndex = 8;
            this.pictureBox02.TabStop = false;
            this.pictureBox02.Click += new System.EventHandler(this.pictureBox02_Click);
            // 
            // Randomize
            // 
            this.Randomize.Location = new System.Drawing.Point(316, 482);
            this.Randomize.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Randomize.Name = "Randomize";
            this.Randomize.Size = new System.Drawing.Size(165, 23);
            this.Randomize.TabIndex = 17;
            this.Randomize.Text = "Randomize (10 Gold)";
            this.Randomize.UseVisualStyleBackColor = true;
            this.Randomize.Click += new System.EventHandler(this.Randomize_Click);
            // 
            // pictureBoxEhh
            // 
            this.pictureBoxEhh.Location = new System.Drawing.Point(813, 121);
            this.pictureBoxEhh.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.pictureBoxEhh.Name = "pictureBoxEhh";
            this.pictureBoxEhh.Size = new System.Drawing.Size(64, 50);
            this.pictureBoxEhh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEhh.TabIndex = 18;
            this.pictureBoxEhh.TabStop = false;
            this.pictureBoxEhh.Visible = false;
            this.pictureBoxEhh.Click += new System.EventHandler(this.pictureBoxEhh_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 190);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "Gold: ";
            // 
            // playerGoldOutput
            // 
            this.playerGoldOutput.AutoSize = true;
            this.playerGoldOutput.Location = new System.Drawing.Point(71, 190);
            this.playerGoldOutput.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.playerGoldOutput.Name = "playerGoldOutput";
            this.playerGoldOutput.Size = new System.Drawing.Size(0, 17);
            this.playerGoldOutput.TabIndex = 20;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(19, 224);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(78, 27);
            this.button1.TabIndex = 32;
            this.button1.Text = "Give Up?";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Planet1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PapayaWhip;
            this.ClientSize = new System.Drawing.Size(776, 554);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.playerGoldOutput);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBoxEhh);
            this.Controls.Add(this.Randomize);
            this.Controls.Add(this.pictureBox33);
            this.Controls.Add(this.pictureBox23);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox03);
            this.Controls.Add(this.pictureBox32);
            this.Controls.Add(this.pictureBox22);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox02);
            this.Controls.Add(this.pictureBox31);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox01);
            this.Controls.Add(this.pictureBox30);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox00);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Planet1";
            this.Text = "Planet1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox00)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox30)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox01)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox03)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox02)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEhh)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox00;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.PictureBox pictureBox30;
        private System.Windows.Forms.PictureBox pictureBox31;
        private System.Windows.Forms.PictureBox pictureBox21;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox01;
        private System.Windows.Forms.PictureBox pictureBox33;
        private System.Windows.Forms.PictureBox pictureBox23;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.PictureBox pictureBox03;
        private System.Windows.Forms.PictureBox pictureBox32;
        private System.Windows.Forms.PictureBox pictureBox22;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox02;
        private System.Windows.Forms.Button Randomize;
        private System.Windows.Forms.PictureBox pictureBoxEhh;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label playerGoldOutput;
        private System.Windows.Forms.Button button1;
    }
}